package com.virtualgsi

import android.app.Application
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File
import java.util.UUID

class MainVM(app: Application) : AndroidViewModel(app) {
    val vms = mutableStateListOf<VmInfo>()
    val running = mutableStateListOf<String>()
    var busy by mutableStateOf<String?>(null)
    var progress by mutableStateOf(-1f)
    var logOf by mutableStateOf<String?>(null)
    var error by mutableStateOf<String?>(null)
    var errorVm by mutableStateOf<String?>(null)
    var bootTick by mutableStateOf(0)
    var kvmMode by mutableStateOf("…")
    private val procs = mutableMapOf<String, Process>()
    private val c get() = getApplication<Application>()
    init { vms.addAll(Store.load(c)); viewModelScope.launch(Dispatchers.IO) { kvmMode = Engine.detectKvm() } }

    private fun upd(v: VmInfo) {
        Store.save(c, v)
        val i = vms.indexOfFirst { it.id == v.id }
        if (i >= 0) vms[i] = v else vms.add(v)
    }
    private fun step(t: String, p: Float) { busy = t; if (p < 0f || kotlin.math.abs(p - progress) >= 0.01f) progress = p }
    fun readLog(id: String) = File(Store.dir(c, id), "vm.log").takeIf { it.exists() }?.readText() ?: "(лог пуст)"

    private fun nameOf(u: Uri) = c.contentResolver.query(u, null, null, null, null)?.use {
        if (it.moveToFirst()) it.getString(it.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)) else null } ?: "gsi.img"

    fun bootFiles(a: String): String { bootTick; return Engine.bootDir(c, a).list().orEmpty().sorted().joinToString(", ") }

    fun missing(a: String): List<String> { bootTick; return Engine.missing(c, a) }

    fun importBoot(arch: String, uris: List<Uri>) = viewModelScope.launch(Dispatchers.IO) {
        val dir = Engine.bootDir(c, arch).apply { mkdirs() }
        uris.forEach { u ->
            val n = nameOf(u)
            val t = when {
                Regex("(?i)kernel|^image|bzimage").containsMatchIn(n) -> "kernel"
                Regex("(?i)ramdisk|initrd").containsMatchIn(n) -> "ramdisk.img"
                n.contains("vendor", true) -> "vendor.img"
                else -> n
            }
            c.contentResolver.openInputStream(u)!!.use { i -> File(dir, t).outputStream().use { i.copyTo(it) } }
        }
        bootTick++
    }

    fun add(uri: Uri) = viewModelScope.launch(Dispatchers.IO) {
        error = null; progress = -1f; busy = "Определение версии Android…"
        try {
            val g = detect(c.contentResolver.openInputStream(uri)!!, nameOf(uri))
            val v = VmInfo(UUID.randomUUID().toString().take(8), "Android ${g.release} (API ${g.sdk})", g.release, g.sdk, "NEW", g.arch, g.ab)
            busy = "Создание виртуальной машины…"
            c.contentResolver.openInputStream(uri)!!.use { i -> File(Store.dir(c, v.id), "source.bin").outputStream().use { i.copyTo(it) } }
            upd(v)
        } catch (e: Throwable) { error = e.message; errorVm = null } finally { busy = null }
    }

    fun run(v: VmInfo) = viewModelScope.launch(Dispatchers.IO) {
        val log = VmLog(File(Store.dir(c, v.id), "vm.log"))
        error = null; var flashed = v.state == "READY"
        try {
            var cur = v
            if (!flashed) {
                step("Первая прошивка GSI…", -1f); log.w("== Первая прошивка ==")
                flash(c, v, log) { t, p -> step(t, p) }; flashed = true; cur = v.copy(state = "READY"); upd(cur)
            }
            step("Запуск виртуальной машины…", -1f); log.w("== Запуск ==")
            val p = Engine.start(c, cur, log, kvmMode); procs[v.id] = p; running.add(v.id)
            Thread { p.waitFor(); running.remove(v.id) }.start()
        } catch (e: Throwable) {
            log.w("ОШИБКА: ${e.stackTraceToString()}")
            if (!flashed) upd(v.copy(state = "FAILED"))
            error = "${v.name}: ${e.message}"; errorVm = v.id
        } finally { busy = null }
    }

    fun stop(id: String) { procs.remove(id)?.destroy(); running.remove(id) }
    fun delete(id: String) { stop(id); Store.dir(c, id).deleteRecursively(); vms.removeAll { it.id == id } }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val ctx = LocalContext.current
            MaterialTheme(if (isSystemInDarkTheme()) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)) { App(viewModel()) }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App(m: MainVM) {
    var showBoot by remember { mutableStateOf(false) }
    var bootArch by remember { mutableStateOf("arm64") }
    var delId by remember { mutableStateOf<String?>(null) }
    val clip = LocalClipboardManager.current
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { it?.let(m::add) }
    val bootPick = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { m.importBoot(bootArch, it) }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Virtual GSI") },
            actions = { IconButton({ showBoot = true }) { Icon(Icons.Default.Settings, "Файлы загрузки") } }) },
        floatingActionButton = { ExtendedFloatingActionButton(onClick = { pick.launch(arrayOf("*/*")) },
            icon = { Icon(Icons.Default.Add, null) }, text = { Text("Загрузить GSI") }) }
    ) { p ->
        LazyColumn(Modifier.fillMaxSize().padding(p), contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 96.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item { KvmCard(m.kvmMode) }
            m.busy?.let { t -> item {
                Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(t, style = MaterialTheme.typography.titleSmall)
                    if (m.progress >= 0f) { LinearProgressIndicator(progress = { m.progress }, modifier = Modifier.fillMaxWidth()); Text("${(m.progress * 100).toInt()}%") }
                    else LinearProgressIndicator(Modifier.fillMaxWidth())
                } } } }
            m.error?.let { e -> item {
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.Warning, null); Text(e, Modifier.weight(1f)) }
                        Row { m.errorVm?.let { id -> TextButton({ m.logOf = id }) { Text("Открыть логи") } }
                            TextButton({ m.error = null }) { Text("Скрыть") } }
                    } } } }
            if (m.vms.isEmpty() && m.busy == null) item {
                Text("Виртуальных машин пока нет.\nНажмите «Загрузить GSI» и выберите образ (.img, .img.xz, .gz, .zip, sparse).",
                    Modifier.fillMaxWidth().padding(vertical = 48.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            items(m.vms, key = { it.id }) { v ->
                val run = v.id in m.running
                ElevatedCard(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(v.name, style = MaterialTheme.typography.titleMedium)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        AssistChip({}, { Text(v.arch) }); AssistChip({}, { Text(if (v.ab) "A/B" else "A-only") })
                        AssistChip({}, { Text(when { run -> "Запущена"; v.state == "READY" -> "Готова"; v.state == "FAILED" -> "Ошибка"; else -> "Не прошита" }) })
                    }
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (run) FilledTonalButton({ m.stop(v.id) }) { Text("Остановить") }
                        else Button({ m.run(v) }, enabled = m.busy == null) { Icon(Icons.Default.PlayArrow, null); Spacer(Modifier.width(4.dp)); Text("Запустить") }
                        TextButton({ m.logOf = v.id }) { Text("Логи") }
                        Spacer(Modifier.weight(1f))
                        IconButton({ delId = v.id }) { Icon(Icons.Default.Delete, "Удалить") }
                    }
                } }
            }
        }
    }

    if (showBoot) AlertDialog(onDismissRequest = { showBoot = false },
        confirmButton = { TextButton({ showBoot = false }) { Text("Готово") } },
        title = { Text("Файлы загрузки") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Выберите сразу kernel, ramdisk и vendor.img для нужной архитектуры.")
            listOf("arm64", "x86_64").forEach { a ->
                Button({ bootArch = a; bootPick.launch(arrayOf("*/*")) }) { Text("$a — выбрать файлы") }
                Text("Есть: " + m.bootFiles(a).ifEmpty { "ничего" }, fontSize = 12.sp)
                Text(m.missing(a).let { if (it.isEmpty()) "✓ Всё есть, можно запускать" else "✗ Не хватает: " + it.joinToString() }, fontSize = 12.sp)
            }
        } })
    delId?.let { id -> AlertDialog(onDismissRequest = { delId = null },
        title = { Text("Удалить виртуальную машину?") }, text = { Text("Образ, данные и логи будут удалены.") },
        confirmButton = { TextButton({ m.delete(id); delId = null }) { Text("Удалить") } },
        dismissButton = { TextButton({ delId = null }) { Text("Отмена") } }) }
    m.logOf?.let { id ->
        val text = remember(id, m.busy) { m.readLog(id) }
        AlertDialog(onDismissRequest = { m.logOf = null },
            confirmButton = { TextButton({ m.logOf = null }) { Text("Закрыть") } },
            dismissButton = { TextButton({ clip.setText(AnnotatedString(text)) }) { Text("Копировать") } },
            title = { Text("Логи") },
            text = { Text(text, Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState()),
                fontFamily = FontFamily.Monospace, fontSize = 11.sp) })
    }
}

@Composable
fun KvmCard(mode: String) {
    val (txt, ok) = when (mode) {
        "direct" -> "KVM доступен — аппаратное ускорение" to true
        "root" -> "KVM доступен через root — аппаратное ускорение" to true
        "none" -> "KVM недоступен — программная эмуляция (медленно). Для ускорения нужен root." to false
        else -> "Проверка KVM…" to false
    }
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(
        containerColor = if (ok) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant)) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(Icons.Default.Info, null); Text(txt)
        }
    }
}
