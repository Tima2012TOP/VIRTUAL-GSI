package com.virtualgsi

import android.app.Application
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File
import java.util.UUID

class MainVM(app: Application) : AndroidViewModel(app) {
    val vms = mutableStateListOf<VmInfo>()
    var busy by mutableStateOf<String?>(null)
    var logOf by mutableStateOf<String?>(null)
    var error by mutableStateOf<String?>(null)
    private val procs = mutableMapOf<String, Process>()
    private val c get() = getApplication<Application>()
    init { vms.addAll(Store.load(c)) }

    private fun upd(v: VmInfo) {
        Store.save(c, v)
        val i = vms.indexOfFirst { it.id == v.id }
        if (i >= 0) vms[i] = v else vms.add(v)
    }
    fun readLog(id: String) = File(Store.dir(c, id), "vm.log").takeIf { it.exists() }?.readText() ?: "(лог пуст)"

    fun add(uri: Uri) = viewModelScope.launch(Dispatchers.IO) {
        error = null; busy = "Определение версии Android…"
        try {
            val (rel, sdk) = detect(c.contentResolver.openInputStream(uri)!!)
            val v = VmInfo(UUID.randomUUID().toString().take(8), "Android $rel (API $sdk)", rel, sdk, "NEW")
            busy = "Создание виртуальной машины…"
            c.contentResolver.openInputStream(uri)!!.use { i -> File(Store.dir(c, v.id), "source.bin").outputStream().use { i.copyTo(it) } }
            upd(v)
        } catch (e: Throwable) { error = e.message } finally { busy = null }
    }

    fun run(v: VmInfo) = viewModelScope.launch(Dispatchers.IO) {
        val log = VmLog(File(Store.dir(c, v.id), "vm.log"))
        try {
            var cur = v
            if (v.state != "READY") {
                busy = "Первая прошивка GSI…"; log.w("== Первая прошивка ==")
                flash(c, v, log); cur = v.copy(state = "READY"); upd(cur)
            }
            busy = "Запуск…"; log.w("== Запуск ==")
            procs[v.id] = Engine.start(c, cur, log)
        } catch (e: Throwable) {
            log.w("ОШИБКА: ${e.stackTraceToString()}"); upd(v.copy(state = "FAILED")); error = "${v.name}: ${e.message}"
        } finally { busy = null }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { App(viewModel()) } }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App(m: MainVM) {
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { it?.let(m::add) }
    Scaffold(
        topBar = { TopAppBar(title = { Text("Virtual GSI") }) },
        floatingActionButton = { FloatingActionButton({ pick.launch(arrayOf("*/*")) }) { Icon(Icons.Default.Add, "Загрузить GSI") } }
    ) { p ->
        Column(Modifier.padding(p).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(if (Engine.kvm()) "KVM доступен — аппаратное ускорение" else "KVM недоступен — программная эмуляция (медленно)")
            m.busy?.let { Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { CircularProgressIndicator(Modifier.size(20.dp)); Text(it) } }
            m.error?.let { Text(it, color = Color(0xFFB00020)) }
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(m.vms, key = { it.id }) { v ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp)) {
                            Text(v.name, style = MaterialTheme.typography.titleMedium)
                            Text(when (v.state) { "READY" -> "Готова" ; "FAILED" -> "Ошибка прошивки" ; else -> "Не прошита (прошьётся при первом запуске)" })
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button({ m.run(v) }, enabled = m.busy == null) { Text("Запустить") }
                                OutlinedButton({ m.logOf = v.id }) { Text("Логи") }
                            }
                        }
                    }
                }
            }
        }
    }
    m.logOf?.let { id ->
        AlertDialog(onDismissRequest = { m.logOf = null },
            confirmButton = { TextButton({ m.logOf = null }) { Text("Закрыть") } },
            title = { Text("Логи") },
            text = { Text(m.readLog(id), Modifier.heightIn(max = 400.dp).verticalScroll(rememberScrollState()),
                fontFamily = FontFamily.Monospace, fontSize = 11.sp) })
    }
}
