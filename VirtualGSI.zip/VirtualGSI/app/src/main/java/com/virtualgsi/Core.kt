package com.virtualgsi

import android.app.ActivityManager
import android.content.Context
import org.json.JSONObject
import org.tukaani.xz.XZInputStream
import java.io.*
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.zip.GZIPInputStream
import java.util.zip.ZipInputStream

data class VmInfo(val id: String, val name: String, val release: String, val sdk: Int, val state: String,
                  val arch: String = "arm64", val ab: Boolean = true) // NEW | READY | FAILED

class VmLog(private val f: File) {
    fun w(s: String) = f.appendText("[${SimpleDateFormat("HH:mm:ss").format(Date())}] $s\n")
}

object Store {
    fun dir(c: Context, id: String) = File(c.filesDir, "vms/$id").apply { mkdirs() }
    fun save(c: Context, v: VmInfo) = File(dir(c, v.id), "vm.json").writeText(
        JSONObject().put("id", v.id).put("name", v.name).put("release", v.release)
            .put("sdk", v.sdk).put("state", v.state).put("arch", v.arch).put("ab", v.ab).toString())
    fun load(c: Context) = File(c.filesDir, "vms").listFiles().orEmpty().mapNotNull {
        runCatching {
            JSONObject(File(it, "vm.json").readText()).let { j ->
                VmInfo(j.getString("id"), j.getString("name"), j.getString("release"), j.getInt("sdk"), j.getString("state"),
                    j.optString("arch", "arm64"), j.optBoolean("ab", true))
            }
        }.getOrNull()
    }
}

/** Разворачивает .zip / .xz, иначе отдаёт как есть. */
fun openImage(src: InputStream): InputStream {
    val raw = BufferedInputStream(src)
    raw.mark(8); val m = ByteArray(6); val n = raw.read(m); raw.reset()
    return when {
        n >= 4 && m[0] == 'P'.code.toByte() && m[1] == 'K'.code.toByte() -> ZipInputStream(raw).also { z ->
            while (true) { val e = z.nextEntry ?: throw IOException("В ZIP нет .img"); if (e.name.endsWith(".img") && listOf("vbmeta", "vendor", "boot", "product").none { e.name.contains(it) }) break }
        }
        n >= 6 && m[0] == 0xFD.toByte() && m[1] == '7'.code.toByte() -> XZInputStream(raw)
        n >= 2 && m[0] == 0x1F.toByte() && m[1] == 0x8B.toByte() -> GZIPInputStream(raw)
        else -> raw
    }
}

data class Gsi(val release: String, val sdk: Int, val arch: String, val ab: Boolean)
private val SDK = mapOf(9 to 28, 10 to 29, 11 to 30, 12 to 31, 13 to 33, 14 to 34, 15 to 35, 16 to 36)
private val TREBLE = Regex("treble_(arm64|a64|arm|x86_64|x86)_([ab])", RegexOption.IGNORE_CASE)
private fun family(x: String) = if (x.startsWith("x86")) "x86_64" else "arm64" // a64/arm работают на aarch64-QEMU

/** Версия, архитектура (arm64/a64/arm/x86/x86_64) и тип (A-only / A/B) из build.prop образа, при неудаче — из имени файла. */
fun detect(src: InputStream, fileName: String): Gsi {
    var rel: String? = null; var sdk: Int? = null; var arch: String? = null; var ab: Boolean? = null
    runCatching {
        openImage(src).use { ins ->
            val buf = ByteArray(1 shl 20); var tail = ""
            while (true) {
                val n = ins.read(buf); if (n < 0) break
                val s = tail + String(buf, 0, n, Charsets.ISO_8859_1)
                if (rel == null) rel = Regex("ro\\.build\\.version\\.release=(\\d+)").find(s)?.groupValues?.get(1)
                if (sdk == null) sdk = Regex("ro\\.build\\.version\\.sdk=(\\d+)").find(s)?.groupValues?.get(1)?.toInt()
                if (arch == null) TREBLE.find(s)?.let { arch = family(it.groupValues[1].lowercase()); ab = it.groupValues[2].lowercase() == "b" }
                if (arch == null) Regex("ro\\.product\\.cpu\\.abi=([a-z0-9_-]+)").find(s)?.let { arch = family(it.groupValues[1]) }
                if (rel != null && sdk != null && arch != null) break
                tail = s.takeLast(96)
            }
        }
    }
    val fr = Regex("(?i)android[-_ ]?(\\d{1,2})").find(fileName)?.groupValues?.get(1)
    val fm = TREBLE.find(fileName)
    val release = rel ?: fr ?: throw IOException("Не удалось определить версию Android — это точно GSI (system.img)?")
    return Gsi(release, sdk ?: SDK[release.toIntOrNull()] ?: 0,
        arch ?: fm?.let { family(it.groupValues[1].lowercase()) } ?: if (fileName.contains("x86", true)) "x86_64" else "arm64",
        ab ?: fm?.let { it.groupValues[2].lowercase() == "b" } ?: true)
}

private fun unsparse(d: DataInputStream, out: File, log: VmLog, onP: (Float) -> Unit) {
    val h = ByteArray(28); d.readFully(h)
    val b = ByteBuffer.wrap(h).order(ByteOrder.LITTLE_ENDIAN)
    val blk = b.getInt(12); val chunks = b.getInt(20); val chs = b.getShort(10).toInt() and 0xFFFF
    val fh = b.getShort(8).toInt() and 0xFFFF; if (fh > 28) d.readFully(ByteArray(fh - 28))
    log.w("sparse: блок=$blk, чанков=$chunks")
    RandomAccessFile(out, "rw").use { f ->
        val total = (b.getInt(16).toLong() and 0xFFFFFFFFL) * blk; f.setLength(total)
        val buf = ByteArray(1 shl 16)
        repeat(chunks) {
            val ch = ByteArray(12); d.readFully(ch); if (chs > 12) d.readFully(ByteArray(chs - 12))
            val c = ByteBuffer.wrap(ch).order(ByteOrder.LITTLE_ENDIAN)
            val size = (c.getInt(4).toLong() and 0xFFFFFFFFL) * blk
            when (val type = c.getShort(0).toInt() and 0xFFFF) {
                0xCAC1 -> { var left = size
                    while (left > 0) { val n = d.read(buf, 0, minOf(left, buf.size.toLong()).toInt())
                        if (n < 0) throw EOFException("Обрыв данных"); f.write(buf, 0, n); left -= n; onP(f.filePointer.toFloat() / total) } }
                0xCAC2 -> { val fill = ByteArray(4); d.readFully(fill)
                    if (fill.any { it != 0.toByte() }) { val bl = ByteArray(blk) { fill[it % 4] }
                        repeat((size / blk).toInt()) { f.write(bl) } } else f.seek(f.filePointer + size) }
                0xCAC3 -> f.seek(f.filePointer + size)
                0xCAC4 -> d.readFully(ByteArray(4))
                else -> throw IOException("Неизвестный тип чанка 0x${type.toString(16)}")
            }
            onP(f.filePointer.toFloat() / total)
        }
    }
}

/** Первая прошивка: source.bin -> system.img (+ userdata.img). Любое исключение = ошибка прошивки. */
fun flash(c: Context, v: VmInfo, log: VmLog, onP: (String, Float) -> Unit = { _, _ -> }) {
    val dir = Store.dir(c, v.id)
    val sys = File(dir, "system.img").apply { delete() }
    log.w("1/3 Конвертация образа"); onP("Конвертация образа", -1f)
    val ins = BufferedInputStream(openImage(File(dir, "source.bin").inputStream()))
    ins.mark(4); val magic = ByteArray(4); ins.read(magic); ins.reset()
    if (ByteBuffer.wrap(magic).order(ByteOrder.LITTLE_ENDIAN).int == 0xED26FF3A.toInt())
        unsparse(DataInputStream(ins), sys, log) { onP("Конвертация sparse → raw", it * 0.85f) }
    else { log.w("образ не sparse — копирую"); sys.outputStream().use { ins.copyTo(it) } }
    log.w("system.img: ${sys.length() shr 20} МБ")

    log.w("2/3 Проверка файловой системы"); onP("Проверка файловой системы", 0.88f)
    RandomAccessFile(sys, "r").use { f ->
        val e = ByteArray(2); f.seek(1080); f.readFully(e)
        val r = ByteArray(4); f.seek(1024); f.readFully(r)
        val ext4 = e[0] == 0x53.toByte() && e[1] == 0xEF.toByte()
        val erofs = ByteBuffer.wrap(r).order(ByteOrder.LITTLE_ENDIAN).int == 0xE0F5E1E2.toInt()
        if (!ext4 && !erofs) throw IOException("system.img не ext4/erofs — образ повреждён")
        log.w("ФС: ${if (ext4) "ext4" else "erofs"}")
    }
    log.w("3/3 Создание userdata.img (8 ГБ, sparse)"); onP("Создание userdata", 0.95f)
    RandomAccessFile(File(dir, "userdata.img"), "rw").use { it.setLength(8L shl 30) }
    log.w("Прошивка завершена успешно"); onP("Готово", 1f)
}

object Engine {
    /** "direct" — /dev/kvm доступен приложению, "root" — доступен через su, "none" — KVM недоступен. */
    fun detectKvm(): String = when {
        File("/dev/kvm").let { it.exists() && it.canRead() && it.canWrite() } -> "direct"
        runCatching { ProcessBuilder("su", "-c", "test -w /dev/kvm").start().waitFor() == 0 }.getOrDefault(false) -> "root"
        else -> "none"
    }

    /** Чего не хватает для запуска гостя этой архитектуры. */
    fun missing(c: Context, arch: String): List<String> {
        val q = File(c.applicationInfo.nativeLibraryDir, if (arch == "x86_64") "libqemu_x86_64.so" else "libqemu_aarch64.so")
        val b = bootDir(c, arch)
        return (listOf(q.name to q) + listOf("kernel", "ramdisk.img", "vendor.img").map { it to File(b, it) })
            .filter { !it.second.exists() }.map { it.first }
    }

    /** Копирует BIOS/ROM-файлы QEMU из assets (кладутся сборкой) и возвращает каталог для -L. */
    fun ensureBios(c: Context): File {
        val d = File(c.filesDir, "bios")
        if (!d.isDirectory) {
            d.mkdirs()
            c.assets.list("qemu-bios").orEmpty().forEach { n ->
                c.assets.open("qemu-bios/$n").use { i -> File(d, n).outputStream().use { i.copyTo(it) } } }
        }
        return d
    }

    fun bootDir(c: Context, arch: String) = File(c.getExternalFilesDir(null), "boot/$arch")

    /** Нужны: libqemu_aarch64.so / libqemu_x86_64.so в jniLibs/arm64-v8a и kernel, ramdisk.img, vendor.img (кнопка «Файлы загрузки»). */
    fun start(c: Context, v: VmInfo, log: VmLog, kvmMode: String): Process {
        val x86 = v.arch == "x86_64"
        val qemu = File(c.applicationInfo.nativeLibraryDir, if (x86) "libqemu_x86_64.so" else "libqemu_aarch64.so")
        val boot = bootDir(c, v.arch)
        (listOf(qemu) + listOf("kernel", "ramdisk.img", "vendor.img").map { File(boot, it) })
            .firstOrNull { !it.exists() }?.let { throw FileNotFoundException("Не найден ${it.name} (${it.path})") }
        val d = Store.dir(c, v.id)
        val kvm = kvmMode != "none" && !x86 // KVM только когда архитектура гостя = архитектуре телефона
        val mi = ActivityManager.MemoryInfo().also { c.getSystemService(ActivityManager::class.java).getMemoryInfo(it) }
        val ram = ((mi.totalMem shr 20) / 2).coerceIn(1536, 4096)
        val cpus = Runtime.getRuntime().availableProcessors().coerceIn(2, 8)
        log.w("Гость: ${v.arch}, ${if (kvm) "KVM" else "TCG (программная эмуляция)"}, RAM $ram МБ, ядер $cpus")
        val args = mutableListOf(qemu.path)
        ensureBios(c).takeIf { it.list().orEmpty().isNotEmpty() }?.let { args += listOf("-L", it.path) }
        args += if (x86) listOf("-machine", "q35", "-cpu", "max") else listOf("-machine", "virt,gic-version=3", "-cpu", if (kvm) "host" else "max")
        args += listOf("-accel", if (kvm) "kvm" else if (x86) "tcg,tb-size=512" else "tcg,thread=multi,tb-size=512",
            "-smp", "$cpus", "-m", "$ram", "-kernel", "$boot/kernel", "-initrd", "$boot/ramdisk.img",
            "-append", "console=${if (x86) "ttyS0" else "ttyAMA0"} androidboot.hardware=ranchu androidboot.selinux=permissive" + (if (v.ab) " androidboot.slot_suffix=_a" else ""),
            "-drive", "if=none,id=s,format=raw,file=$d/system.img,readonly=on", "-device", "virtio-blk-pci,drive=s",
            "-drive", "if=none,id=v,format=raw,file=$boot/vendor.img,readonly=on", "-device", "virtio-blk-pci,drive=v",
            "-drive", "if=none,id=u,format=raw,file=$d/userdata.img", "-device", "virtio-blk-pci,drive=u",
            "-device", "virtio-gpu-pci", "-device", "virtio-keyboard-pci", "-device", "virtio-tablet-pci",
            "-netdev", "user,id=n", "-device", "virtio-net-pci,netdev=n,romfile=",
            "-display", "none", "-vnc", "127.0.0.1:1", "-serial", "stdio")
        log.w(args.joinToString(" "))
        val cmd = if (kvmMode == "root" && kvm) listOf("su", "-c", args.joinToString(" ") { "'$it'" }) else args
        val p = ProcessBuilder(cmd).redirectErrorStream(true).start()
        Thread { p.inputStream.bufferedReader().forEachLine { log.w(it) }; log.w("QEMU завершился, код ${p.waitFor()}") }.start()
        return p
    }
}
