package com.virtualgsi

import android.content.Context
import org.json.JSONObject
import org.tukaani.xz.XZInputStream
import java.io.*
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.zip.ZipInputStream

data class VmInfo(val id: String, val name: String, val release: String, val sdk: Int, val state: String) // NEW | READY | FAILED

class VmLog(private val f: File) {
    fun w(s: String) = f.appendText("[${SimpleDateFormat("HH:mm:ss").format(Date())}] $s\n")
}

object Store {
    fun dir(c: Context, id: String) = File(c.filesDir, "vms/$id").apply { mkdirs() }
    fun save(c: Context, v: VmInfo) = File(dir(c, v.id), "vm.json").writeText(
        JSONObject().put("id", v.id).put("name", v.name).put("release", v.release)
            .put("sdk", v.sdk).put("state", v.state).toString())
    fun load(c: Context) = File(c.filesDir, "vms").listFiles().orEmpty().mapNotNull {
        runCatching {
            JSONObject(File(it, "vm.json").readText()).let { j ->
                VmInfo(j.getString("id"), j.getString("name"), j.getString("release"), j.getInt("sdk"), j.getString("state"))
            }
        }.getOrNull()
    }
}

/** Разворачивает .zip / .xz, иначе отдаёт как есть. */
fun openImage(src: InputStream): InputStream {
    val raw = BufferedInputStream(src)
    raw.mark(8); val m = ByteArray(6); val n = raw.read(m); raw.reset()
    return when {
        n >= 4 && m[0] == 'P'.code.toByte() && m[1] == 'K'.code.toByte() -> ZipInputStream(raw).also { z ->
            while (true) { val e = z.nextEntry ?: throw IOException("В ZIP нет .img"); if (e.name.endsWith(".img")) break }
        }
        n >= 6 && m[0] == 0xFD.toByte() && m[1] == '7'.code.toByte() -> XZInputStream(raw)
        else -> raw
    }
}

/** Определение версии: ищем ro.build.version.* в build.prop внутри образа. */
fun detect(src: InputStream): Pair<String, Int> {
    var rel: String? = null; var sdk: Int? = null
    openImage(src).use { ins ->
        val buf = ByteArray(1 shl 20); var tail = ""
        while (rel == null || sdk == null) {
            val n = ins.read(buf); if (n < 0) break
            val s = tail + String(buf, 0, n, Charsets.ISO_8859_1)
            if (rel == null) rel = Regex("ro\\.build\\.version\\.release=(\\d+)").find(s)?.groupValues?.get(1)
            if (sdk == null) sdk = Regex("ro\\.build\\.version\\.sdk=(\\d+)").find(s)?.groupValues?.get(1)?.toInt()
            tail = s.takeLast(64)
        }
    }
    return (rel ?: throw IOException("Не удалось определить версию Android — это точно system.img от GSI?")) to (sdk ?: 0)
}

private fun unsparse(d: DataInputStream, out: File, log: VmLog) {
    val h = ByteArray(28); d.readFully(h)
    val b = ByteBuffer.wrap(h).order(ByteOrder.LITTLE_ENDIAN)
    val blk = b.getInt(12); val chunks = b.getInt(20)
    log.w("sparse: блок=$blk, чанков=$chunks")
    RandomAccessFile(out, "rw").use { f ->
        f.setLength(b.getInt(16).toLong() * blk)
        val buf = ByteArray(1 shl 16)
        repeat(chunks) {
            val ch = ByteArray(12); d.readFully(ch)
            val c = ByteBuffer.wrap(ch).order(ByteOrder.LITTLE_ENDIAN)
            val size = (c.getInt(4).toLong() and 0xFFFFFFFFL) * blk
            when (val type = c.getShort(0).toInt() and 0xFFFF) {
                0xCAC1 -> { var left = size
                    while (left > 0) { val n = d.read(buf, 0, minOf(left, buf.size.toLong()).toInt())
                        if (n < 0) throw EOFException("Обрыв данных"); f.write(buf, 0, n); left -= n } }
                0xCAC2 -> { val fill = ByteArray(4); d.readFully(fill)
                    if (fill.any { it != 0.toByte() }) { val bl = ByteArray(blk) { fill[it % 4] }
                        repeat((size / blk).toInt()) { f.write(bl) } } else f.seek(f.filePointer + size) }
                0xCAC3 -> f.seek(f.filePointer + size)
                0xCAC4 -> d.skipBytes(4)
                else -> throw IOException("Неизвестный тип чанка 0x${type.toString(16)}")
            }
        }
    }
}

/** Первая прошивка: source.bin -> system.img (+ userdata.img). Любое исключение = ошибка прошивки. */
fun flash(c: Context, v: VmInfo, log: VmLog) {
    val dir = Store.dir(c, v.id)
    val sys = File(dir, "system.img").apply { delete() }
    log.w("1/3 Конвертация образа")
    val ins = BufferedInputStream(openImage(File(dir, "source.bin").inputStream()))
    ins.mark(4); val magic = ByteArray(4); ins.read(magic); ins.reset()
    if (ByteBuffer.wrap(magic).order(ByteOrder.LITTLE_ENDIAN).int == 0xED26FF3A.toInt())
        unsparse(DataInputStream(ins), sys, log)
    else { log.w("образ не sparse — копирую"); sys.outputStream().use { ins.copyTo(it) } }
    log.w("system.img: ${sys.length() shr 20} МБ")

    log.w("2/3 Проверка файловой системы")
    RandomAccessFile(sys, "r").use { f ->
        val e = ByteArray(2); f.seek(1080); f.readFully(e)
        val r = ByteArray(4); f.seek(1024); f.readFully(r)
        val ext4 = e[0] == 0x53.toByte() && e[1] == 0xEF.toByte()
        val erofs = ByteBuffer.wrap(r).order(ByteOrder.LITTLE_ENDIAN).int == 0xE0F5E1E2.toInt()
        if (!ext4 && !erofs) throw IOException("system.img не ext4/erofs — образ повреждён")
        log.w("ФС: ${if (ext4) "ext4" else "erofs"}")
    }
    log.w("3/3 Создание userdata.img (8 ГБ, sparse)")
    RandomAccessFile(File(dir, "userdata.img"), "rw").use { it.setLength(8L shl 30) }
    log.w("Прошивка завершена успешно")
}

object Engine {
    fun kvm() = File("/dev/kvm").let { it.exists() && it.canRead() && it.canWrite() }

    /** Нужны: libqemu.so в jniLibs/arm64-v8a и файлы kernel, ramdisk.img, vendor.img в Android/data/com.virtualgsi/files/boot/ */
    fun start(c: Context, v: VmInfo, log: VmLog): Process {
        val qemu = File(c.applicationInfo.nativeLibraryDir, "libqemu.so")
        val boot = File(c.getExternalFilesDir(null), "boot")
        val need = listOf(qemu) + listOf("kernel", "ramdisk.img", "vendor.img").map { File(boot, it) }
        need.firstOrNull { !it.exists() }?.let { throw FileNotFoundException("Не найден ${it.path}") }
        val d = Store.dir(c, v.id)
        val accel = if (kvm()) "kvm" else "tcg"
        log.w("Ускорение: $accel")
        val args = listOf(qemu.path, "-machine", "virt,gic-version=3", "-accel", accel,
            "-cpu", if (kvm()) "host" else "max", "-smp", "4", "-m", "4096",
            "-kernel", "$boot/kernel", "-initrd", "$boot/ramdisk.img",
            "-append", "console=ttyAMA0 androidboot.hardware=ranchu androidboot.selinux=permissive",
            "-drive", "if=none,id=s,format=raw,file=${d}/system.img,readonly=on", "-device", "virtio-blk-pci,drive=s",
            "-drive", "if=none,id=v,format=raw,file=$boot/vendor.img,readonly=on", "-device", "virtio-blk-pci,drive=v",
            "-drive", "if=none,id=u,format=raw,file=${d}/userdata.img", "-device", "virtio-blk-pci,drive=u",
            "-device", "virtio-gpu-pci", "-device", "virtio-keyboard-pci", "-device", "virtio-tablet-pci",
            "-netdev", "user,id=n", "-device", "virtio-net-pci,netdev=n",
            "-display", "none", "-vnc", "127.0.0.1:1", "-serial", "stdio")
        log.w(args.joinToString(" "))
        val p = ProcessBuilder(args).redirectErrorStream(true).start()
        Thread { p.inputStream.bufferedReader().forEachLine { log.w(it) }; log.w("QEMU завершился, код ${p.waitFor()}") }.start()
        return p
    }
}
